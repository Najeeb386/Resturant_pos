<?php

use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\POSController;
use App\Http\Controllers\API\TablesController;
use App\Http\Controllers\API\MenuController;
use App\Http\Controllers\API\KitchenController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/user', [AuthController::class, 'user']);

    // POS routes
    Route::post('/pos/orders', [POSController::class, 'createOrder']);
    Route::get('/pos/orders', [POSController::class, 'getOrders']);
    Route::patch('/pos/orders/{id}/status', [POSController::class, 'updateOrderStatus']);

    // Tables routes
    Route::get('/tables', [TablesController::class, 'index']);
    Route::post('/tables', [TablesController::class, 'store']);
    Route::patch('/tables/{id}', [TablesController::class, 'update']);

    // Menu routes
    Route::get('/menu', [MenuController::class, 'index']);
    Route::post('/menu/categories', [MenuController::class, 'storeCategory']);
    Route::post('/menu/items', [MenuController::class, 'storeItem']);

    // Kitchen routes
    Route::get('/kitchen/orders', [KitchenController::class, 'getOrders']);
    Route::patch('/kitchen/orders/{orderId}/items/{itemId}', [KitchenController::class, 'updateOrderItemStatus']);
});

// DineDesk Flutter Mobile App API Routes
Route::prefix('v1')->group(function () {
    Route::post('/login', [\App\Http\Controllers\API\MobileSyncController::class, 'login']);

    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/bootstrap', [\App\Http\Controllers\API\MobileSyncController::class, 'bootstrap']);
        Route::post('/sync/orders', [\App\Http\Controllers\API\MobileSyncController::class, 'syncOrders']);
        Route::patch('/orders/{id}/status', [\App\Http\Controllers\API\MobileSyncController::class, 'updateOrderStatus']);
        Route::post('/orders/{id}/confirm-update', [\App\Http\Controllers\API\MobileSyncController::class, 'confirmOrderUpdate']);
        Route::post('/tables', [\App\Http\Controllers\API\MobileSyncController::class, 'createTable']);
        Route::patch('/tables/{id}', [\App\Http\Controllers\API\MobileSyncController::class, 'updateTable']);
        Route::delete('/tables/{id}', [\App\Http\Controllers\API\MobileSyncController::class, 'deleteTable']);
    });
});